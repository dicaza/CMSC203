/*
 * Class: CMSC203
 * Instructor: Gary Thai
 * Description: This class is everything to do
 * with the patient and their information
 * Due: 10/04/2024
 * Platform/Compipler: Eclipse
 * I pledge that I have completed the programming assignment independently
 * from a student or any source. I have not given my code to any student
 * David Icaza
 */
public class Patient 
{
	//name attributes
	private String firstName;
	private String middleName;
	private String lastName;
	
	//address attributes
	private String address;
	private String city;
	private String state;
	private String zipCode;
	
	//phone attributes
	private String phoneNumber;
	private String eContactName;
	private String eContactNum;
	
	//no-arg constructor
	public Patient()
	{
		
	}
	
	//constructor that initializes patient's names
	public Patient(String f, String m, String l)
	{
		firstName = f;
		middleName = m;
		lastName = l;
	}
	
	//constructor that initializes all attributes
	public Patient(String f, String m, String l,
				   String a, String c, String s,
				   String z, String p, String eN,
				   String eC)
	{
		firstName = f;
		middleName = m;
		lastName = l;
		address = a;
		city = c;
		state = s;
		zipCode = z;
		phoneNumber = p;
		eContactName = eN;
		eContactNum = eC;
	}
	
	//Accessors
	public String getFirstName()
	{
		return firstName;
	}
	
	public String getMiddleName()
	{
		return middleName;
	}
	
	public String getLastName()
	{
		return lastName;
	}
	
	public String getAddress()
	{
		return address;
	}
	
	public String getCity()
	{
		return city;
	}
	
	public String getState()
	{
		return state;
	}
	
	public String getZipCode()
	{
		return zipCode;
	}
	
	public String getPhoneNumber()
	{
		return phoneNumber;
	}
	
	public String getEmergencyContactName()
	{
		return eContactName;
	}
	
	public String getEmergencycontactNumber()
	{
		return eContactNum;
	}
	
	//Mutators
	public void setFirstName(String f)
	{
		firstName = f;
	}
	
	public void setMiddleName(String m)
	{
		middleName = m;
	}
	
	public void setLastName(String l)
	{
		lastName = l;
	}
	
	public void setAddress(String a)
	{
		address = a;
	}
	
	public void setCity(String c)
	{
		city = c;
	}
	
	public void setState(String s)
	{
		state = s;
	}
	
	public void setZipCode(String z)
	{
		zipCode = z;
	}
	
	public void setPhoneNumber(String pNum)
	{
		phoneNumber = pNum;
	}
	
	public void setEmergencyContactName(String eConName)
	{
		eContactName = eConName;
	}
	
	public void setEmergencyContactNumber(String eConNum)
	{
		eContactNum = eConNum;
	}
	
	//Method putting all name attributes together
	public String buildFullName()
	{
		String fName = firstName + " " + middleName +
				" " + lastName;
		return fName;
	}
	
	//Method putting all the address attributes together
	public String buildAddress()
	{
		String fullAddress = address + " " + city + " " +
							 state + " " + zipCode;
		return fullAddress;
	}
	
	//Method putting all the emergency contact attributes together
	public String buildEmergencyContact()
	{
		String eContact = eContactName + " " + eContactNum;
		return eContact;
	}
	
	//toString method to display all the information of the patient
	public String toString()
	{
		return("  Name: " + buildFullName() + "\n  Address: " +
				buildAddress() + "\n  Emergency Contact: " + 
				buildEmergencyContact());
	}
}
