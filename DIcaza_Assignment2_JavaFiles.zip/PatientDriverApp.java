/*
 * Class: CMSC203
 * Instructor: Gary Thai
 * Description: This class displays everything from the patient
 * to their procedures and also calculates all the charges
 * Due: 10/04/2024
 * Platform/Compipler: Eclipse
 * I pledge that I have completed the programming assignment independently
 * from a student or any source. I have not given my code to any student
 * David Icaza
 */
public class PatientDriverApp 
{
	public static void main(String[] args)
	{
		//Patient information
		Patient p1 = new Patient();
		p1.setFirstName("Marco");
		p1.setMiddleName("Van");
		p1.setLastName("Basten");
		p1.setAddress("205 Cedar Avenue");
		p1.setCity("Gaithersburg");
		p1.setState("MD");
		p1.setZipCode("20877");
		p1.setEmergencyContactName("Ruud Gullit");
		p1.setEmergencyContactNumber("301-828-7724");
		
		//Patient procedure
		Procedure pr1 = new Procedure ();
		pr1.setName("CT Scan");
		pr1.setDate("05/08/2010");
		pr1.setPractitioner("Dr. Maldini");
		pr1.setCharge(1907.48);
		
		Procedure pr2 = new Procedure();
		pr2.setName("Rhinoplasty");
		pr2.setDate("05/10/2010");
		pr2.setPractitioner("Dr. Baresi");
		pr2.setCharge(3187.23);
		
		Procedure pr3 = new Procedure();
		pr3.setName("Colonoscopy");
		pr3.setDate("05/30/2010");
		pr3.setPractitioner("Dr. Shevchenko");
		pr3.setCharge(2475.71);
		//Display
		displayPatient(p1);
		
		displayProcedure(pr1);
		displayProcedure(pr2);
		displayProcedure(pr3);
		
		double totalCharge = calculateTotalCharges(pr1, pr2, pr3);
		System.out.printf("\nTotal Charges: $%,.2f%n", totalCharge);
		
		System.out.println("\nStudent Name: David Icaza");
		System.out.println("MC#: 21133494");
		System.out.println("Due Date: 10/04/2024");
		
		System.out.println("\n\nThe program was developed by a student"
				+ "\nStudent: <David Icaza> <10/04/2024>");
		
	}

	//Method to display patient information
	private static void displayPatient(Patient p) 
	{
		System.out.println("Patient info: ");
		System.out.println(p.toString());
	}
	
	//Method to display procedure information
	private static void displayProcedure(Procedure p)
	{
		System.out.println(p.toString());
	}
	
	//Method to calculate total charges
	public static double calculateTotalCharges(Procedure p1,
											   Procedure p2,
											   Procedure p3)
	{
		double total = 0.0;
		
		total += p1.getCharge();
		total += p2.getCharge();
		total += p3.getCharge();
		
		return total;
	}
	

}
