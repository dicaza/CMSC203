/*
 * Class: CMSC203
 * Instructor: Gary Thai
 * Description: This class sets up everything for the 
 * patient's procedures including the cost of each
 * Due: 10/04/2024
 * Platform/Compipler: Eclipse
 * I pledge that I have completed the programming assignment independently
 * from a student or any source. I have not given my code to any student
 * David Icaza
 */
public class Procedure 
{
	//attributes
	private String name;
	private String date;
	private String practitioner;
	private double charge;
	
	//no arg constructor
	public Procedure()
	{

	}
	
	//constructor that initializes procedure's name and date
	public Procedure(String n, String d)
	{
		name = n;
		date = d;
	}
	
	//constructor that initializes all attributes
	public Procedure(String n, String d, String p, double c)
	{
		name = n;
		date = d;
		practitioner = p;
		charge = c;
	}
	
	//Accessors
	public String getName()
	{
		return name;
	}
	
	public String getDate()
	{
		return date;
	}
	
	public String getPractitioner()
	{
		return practitioner;
	}
	
	public double getCharge()
	{
		return charge;
	}
	
	//Setters
	public void setName(String n)
	{
		name = n;
	}
	
	public void setDate(String d)
	{
		date = d;
	}
	
	public void setPractitioner(String p)
	{
		practitioner = p;
	}
	
	public void setCharge(double c)
	{
		charge = c;
	}
	
	//toString method
	public String toString()
	{                    
	    return("\n        Procedure: " + name + 
	    	   "\n        ProcedureDate: " + date +
	    	   "\n        Practitioner: " + practitioner +
	    	   "\n        Charge: " + charge);
	}
}
